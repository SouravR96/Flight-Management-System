package net.javaguides.sms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import net.javaguides.sms.entity.Flight;
import net.javaguides.sms.service.FlightService;

@Controller
public class FlightController {

	private FlightService flightService;

	public FlightController(FlightService flightService) {
		super();
		this.flightService = flightService;
	}

	// handler method to handle list flights and return mode and view
	@GetMapping("/flights")
	public String listFlights(Model model) {
		model.addAttribute("flights", flightService.getAllFlights());
		return "flights";
	}

	@GetMapping("/flights/new")
	public String createFlightForm(Model model) {

		// create flight object to hold flight form data
		Flight flight = new Flight();
		model.addAttribute("flight", flight);
		return "create_flight";

	}

	@PostMapping("/flights")
	public String saveFlight(@ModelAttribute("flight") Flight flight) {
		flightService.saveFlight(flight);
		return "redirect:/flights";
	}

	@GetMapping("/flights/edit/{id}")
	public String editFlightForm(@PathVariable Long id, Model model) {
		model.addAttribute("flight", flightService.getFlightById(id));
		return "edit_flight";
	}

	@PostMapping("/flights/{id}")
	public String updateFlight(@PathVariable Long id, @ModelAttribute("flight") Flight flight, Model model) {

		// get flight from database by id
		Flight existingFlight = flightService.getFlightById(id);
		existingFlight.setId(id);
		existingFlight.setFlightName(flight.getFlightName());
		existingFlight.setFlightSource(flight.getFlightSource());
		existingFlight.setFlightDest(flight.getFlightDest());
		existingFlight.setFlightDate(flight.getFlightDate());
		existingFlight.setFlightFare(flight.getFlightFare());
		existingFlight.setUserId(flight.getUserId());
		existingFlight.setUserName(flight.getUserName());
		existingFlight.setUserGender(flight.getUserGender());

		// save updated flight object
		flightService.updateFlight(existingFlight);
		return "redirect:/flights";
	}

	// handler method to handle delete flight request

	@GetMapping("/flights/{id}")
	public String deleteFlight(@PathVariable Long id) {
		flightService.deleteFlightById(id);
		return "redirect:/flights";
	}

}
