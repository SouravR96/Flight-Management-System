package net.javaguides.sms.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "flights")
public class Flight {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "flight_name", nullable = false)
	private String flightName;

	@Column(name = "flight_source")
	private String flightSource;

	@Column(name = "flight_Dest")
	private String flightDest;

	@Column(name = "flight_Date")
	private String flightDate;

	@Column(name = "flight_Fare")
	private int flightFare;

	@Column(name = "user_Id", nullable = true)
	private int userId;
	@Column(name = "user_Name", nullable = true)
	private String userName;

	@Column(name = "user_Gender", nullable = true)
	private String userGender;

	public Flight() {

	}

	public Flight(Long id, String flightName, String flightSource, String flightDest, String flightDate, int flightFare,
			int userId, String userName, String userGender) {
		super();
		this.id = id;
		this.flightName = flightName;
		this.flightSource = flightSource;
		this.flightDest = flightDest;
		this.flightDate = flightDate;
		this.flightFare = flightFare;
		this.userId = userId;
		this.userName = userName;
		this.userGender = userGender;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getFlightSource() {
		return flightSource;
	}

	public void setFlightSource(String flightSource) {
		this.flightSource = flightSource;
	}

	public String getFlightDest() {
		return flightDest;
	}

	public void setFlightDest(String flightDest) {
		this.flightDest = flightDest;
	}

	public String getFlightDate() {
		return flightDate;
	}

	public void setFlightDate(String flightDate) {
		this.flightDate = flightDate;
	}

	public int getFlightFare() {
		return flightFare;
	}

	public void setFlightFare(int flightFare) {
		this.flightFare = flightFare;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserGender() {
		return userGender;
	}

	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}

}