package net.javaguides.sms.service;

import java.util.List;

import net.javaguides.sms.entity.Flight;

public interface FlightService {
	List<Flight> getAllFlights();
	
	Flight saveFlight(Flight flight);
	
	Flight getFlightById(Long id);
	
	Flight updateFlight(Flight flight);
	
	void deleteFlightById(Long id);
}
