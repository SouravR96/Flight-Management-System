package net.javaguides.sms.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import net.javaguides.sms.entity.Flight;
import net.javaguides.sms.repository.FlightRepository;
import net.javaguides.sms.service.FlightService;

@Service
public class FlightServiceImpl implements FlightService{

	private FlightRepository flightRepository;
	
	public FlightServiceImpl(FlightRepository flightRepository) {
		super();
		this.flightRepository = flightRepository;
	}

	@Override
	public List<Flight> getAllFlights() {
		return flightRepository.findAll();
	}

	@Override
	public Flight saveFlight(Flight flight) {
		return flightRepository.save(flight);
	}

	@Override
	public Flight getFlightById(Long id) {
		return flightRepository.findById(id).get();
	}

	@Override
	public Flight updateFlight(Flight flight) {
		return flightRepository.save(flight);
	}

	@Override
	public void deleteFlightById(Long id) {
		flightRepository.deleteById(id);	
	}

}
