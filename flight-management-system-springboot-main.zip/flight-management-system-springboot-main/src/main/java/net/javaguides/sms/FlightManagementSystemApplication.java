package net.javaguides.sms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import net.javaguides.sms.entity.Flight;
import net.javaguides.sms.repository.FlightRepository;

@SpringBootApplication
public class FlightManagementSystemApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(FlightManagementSystemApplication.class, args);
	}

	@Autowired
	private FlightRepository flightRepository;

	@Override
	public void run(String... args) throws Exception {

//		Flight flight1 = new Flight("INDIGO", "Kolkata", "Delhi", "2023-03-31", 9000);
//		flightRepository.save(flight1);

	}

}
